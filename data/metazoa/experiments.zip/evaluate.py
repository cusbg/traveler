#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
"""

import common
import argparse
import numpy as np
import sys
from datetime import datetime


__author__ = "David Hoksza"
__email__ = "david.hoksza@mff.cuni.cz"
__license__ = 'X11'


def evaluate_logsdirectory(dir):
    organisms = set()
    results = {}
    for log in common.find_files_recursively(dir, "*.out"):
        [org1,org2] = log.replace(".out","").replace(dir+"\\","").split("-")
        organisms.add(org1)
        organisms.add(org2)
        with common.open_file(log) as f:
            line = f.readline()
            time_start = datetime.strptime(line.split(" ")[0], "%H:%M:%S:%f")
            overlaps = 0
            ted = 0
            for line in f:
                if "Overlaps computed" in line:
                    overlaps = int(line.split("found ")[1].split(" ")[0])
                if "Computed Tree-Edit-Distance" in line:
                    ted = int(line.split("= ")[1])
            time_end = datetime.strptime(line.split(" ")[0], "%H:%M:%S:%f")
            duration = time_end - time_start
            if duration.total_seconds() < 0:
                duration = (datetime.strptime("23:59:59:99", "%H:%M:%S:%f") - time_start) + (time_end - datetime.strptime("00:00:00:00", "%H:%M:%S:%f"))
            results["{}-{}".format(org1, org2)] = {
                "overlaps": overlaps,
                "time": duration.total_seconds(),
                "ted": ted,
            }

    print("# ----------- All-vs-all metazoa -----------")
    print("# column=target, row=template")
    print("# TED / number of overlaps / time in seconds")
    print()
    first = True
    results_vectors = []
    for o1 in sorted(organisms):
        line = "{:^30}\t".format(o1)
        header = "{:^30}\t".format("")
        results_vector = []
        for o2 in sorted(organisms):
            header += "{:^30}\t".format(o2)
            key = "{}-{}".format(o1, o2)
            if key in results:
                line += "{:^8} / {:^8} / {:^8.4}\t".format(results[key]["ted"], results[key]["overlaps"], results[key]["time"])
                results_vector.append(results[key])
            else:
                line += "{:^30}\t".format("")

        results_vectors.append(sorted(results_vector, key = lambda r: r["ted"] ))
        if first:
            print(header)
            first=False
        print(line)

    print()
    print("# -----------  TED and overlaps by ranking ----------- ")
    print("  \t{:8}\t{:8}\t{:8}".format("TED", "OL(AVG)", "OL(STDDEV)"))
    for i in range(len(results_vectors[0])):
        ted = np.mean([rv[i]["ted"] for rv in results_vectors])
        overlaps = [rv[i]["overlaps"] for rv in results_vectors]
        ol_avg = np.mean(overlaps)
        ol_stddev = np.std(overlaps)
        print("{:2d}\t{:8.2f}\t{:8.2f}\t{:8.2f}".format(i+1, ted, ol_avg, ol_stddev))
        # print("{:2d} & {:8.2f} &{:8.2f} ({:.2f}) \\\\".format(i+1, ted, ol_avg, ol_stddev))




def main():
    evaluate_logsdirectory(args.directory)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("-d", "--directory",
                        metavar='DIR',
                        help="Directory with log files")

    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)

    args = parser.parse_args()

    main()