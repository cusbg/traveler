#ifndef	__RMDEFS__
#define	__RMDEFS__

#define	FALSE	0
#define	TRUE	1
#define	UNDEF	(-1)

#define	MIN(a,b)	((a)<(b)?(a):(b))
#define	MAX(a,b)	((a)>(b)?(a):(b))

#define	DT_FASTN	"fastn"
#define	DT_PIR		"pir"
#define	DT_GENBANK	"gb"

#endif
